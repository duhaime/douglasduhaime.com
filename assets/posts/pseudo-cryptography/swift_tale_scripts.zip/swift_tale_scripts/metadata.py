from __future__ import division
import glob

with open("TCPtexts.txt") as m:
        m_s = m.read().split("\n")
        
        for i in glob.glob("ecco_tcp\\*.txt"):

                read_letters = 0

                i_read = open(i).read().lower()
                
                l_dict = {}

                for j in i_read:
                        if j.isalpha():
                                read_letters += 1
                                if j not in l_dict.keys():
                                        l_dict[j] = 1
                                else:
                                        l_dict[j] += 1


                #print l_dict

                try:
                        print l_dict["o"] / read_letters,
                except:
                        print "no letter o in ",i
                
                file_name = i.split("\\")[-1][:-4]

                for k in m_s:
        
                        rows = k.split("\t")

                        if len(rows) > 1:
                        
                                metadata_filename = rows[2]
                                #print "metadata filename",metadata_filename, file_name
                        
                                if metadata_filename.strip() == file_name.strip():
                                        date = rows[1].replace('"',"")

                                        print date

                

                        
