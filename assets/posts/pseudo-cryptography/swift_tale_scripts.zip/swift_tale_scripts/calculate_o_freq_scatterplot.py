from matplotlib import pyplot

x_vals = []
y_vals = []

def scatterplot(x,y):
    pyplot.plot(x,y,'b.')
    pyplot.xlim(1700,1800)
    pyplot.ylim(0,.15)
    pyplot.title("Relative Frequency of the Letter 'O'")
    pyplot.show()
    
    
with open("C:\\Users\\dduhaime\\Desktop\\data\\ecco_o_freq_by_year.txt") as f:

    o_dict = {}
    
    f = f.read().split("\n")
    for i in f:
        i_s = i.split()

        if len(i_s) == 2:
            if i_s[1] in o_dict.keys():
                
                o_dict[ i_s[1] ].append( i_s[0] )

            elif i_s[1] not in o_dict.keys():
                o_dict[ i_s[1] ] = [(i_s[0])]

with open("aggregate_relative_o_by_year.txt","w") as out:
    for k in o_dict:

        print k
        
        x_vals.append( [float(k)] )

        y_vals_for_k = [ float(l) for l in o_dict[k][0:5] ]
        
        y_vals.append( y_vals_for_k )

        out.write(str(k) + "\t" + str(o_dict[k]) + "\n")

print x_vals, y_vals
scatterplot( x_vals, y_vals)
