from __future__ import division
from matplotlib import pyplot
from numpy import arange
import operator

x_axis = []
y_axis = []

read_letters = 0

def barplot(labels,data):
    pos=arange(len(data))
    pyplot.xticks(pos+0.4,labels)
    pyplot.bar(pos,data)
    pyplot.show()


with open("tale_of_a_tub.txt") as f:

        l_dict = {}
        
        f = f.read().lower()

        for i in f:
                if i.isalpha():

                        read_letters += 1
                        
                        if i not in l_dict.keys():
                                l_dict[i] = 1
                        else:
                                l_dict[i] += 1

        #sort dictionary values by decreasing values; see http://stackoverflow.com/questions/613183/sort-a-python-dictionary-by-value

        sorted_dict = sorted(l_dict.iteritems(), key=operator.itemgetter(1), reverse=True)
        
        for j in sorted_dict:
                print j[0]
                
                if ord(j[0]) < 128:
                        x_axis.append(j[0])
                        y_axis.append(j[1] / read_letters )
                        

        #we want x axis to be letters, organized by highest frequency
        #and y axis to be counts of the indicated letter

print x_axis, y_axis

barplot(x_axis,y_axis)
        
