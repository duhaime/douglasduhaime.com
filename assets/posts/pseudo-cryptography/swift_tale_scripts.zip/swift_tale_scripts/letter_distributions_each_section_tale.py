from __future__ import division
import glob

dict_list = []

#first find counts per letter per section        
for i in glob.glob("C:\\Users\\dduhaime\\Desktop\\data\\tale_sections\\*.txt"):

    read_letters = 0

    i_read = open(i).read().lower()
                
    l_dict = {}

    for j in i_read:
        if j.isalpha():
            if ord(j) < 128:
                read_letters += 1
                if j not in l_dict.keys():
                    l_dict[j] = 1
                else:
                    l_dict[j] += 1

    #now normalize counts
    normalized_dict = {}

    for y in l_dict:
        normalized_dict[y] = l_dict[y] / read_letters

    dict_list.append(normalized_dict)        

#we now have a list of dicts. We want x_axis values a:z, and y_axis list with all values of each letter in a:z
aggregate_dict = {}

for q in dict_list:
    for a in q:
        #print a
        if a in aggregate_dict.keys():
            aggregate_dict[a].append( q[a] )
        else:
            aggregate_dict[a] = [q[a]]

x_vals = []
y_vals = []

#now aggregate_dict contains each letter with ordinal < 128, and all of the relative frequencies of that letter in each section of the tale. Let's plot                
#we can write this data to disk
with open("aggregate_counts_each_letter_per_section.txt","w") as out:
    for u in aggregate_dict:
        for v in aggregate_dict[u]:
            #print v
            out.write(str(u) + "\t" + str(v) + "\n" )
                  
        x_vals.append(u)
        y_vals.append(aggregate_dict[u])

########
# PLOT #
########

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator

x_data = [ord(i) for i in x_vals]
y_data = y_vals

for q in y_vals:
        if len(q) == 11:
            q.append( float(sum(q))/len(q) )

for q in y_vals:
        print len(q)


def ord_to_char(v, p=None):
    return chr(int(v))

fig, ax = plt.subplots()
ax.plot(x_data, y_data, 'o')
ax.xaxis.set_major_formatter(FuncFormatter(ord_to_char))
ax.xaxis.set_major_locator(MultipleLocator(1))
plt.title("Frequencies of Characters in Swift's Tale of a Tub")
plt.show()

